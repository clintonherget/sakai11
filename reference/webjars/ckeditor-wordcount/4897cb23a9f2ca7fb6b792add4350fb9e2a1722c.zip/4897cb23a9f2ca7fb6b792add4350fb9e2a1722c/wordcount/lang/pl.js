﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'pl', {
    WordCount: 'Słów:',
    CharCount: 'Znaków:',
    CharCountWithHTML: 'Znaków (wraz z kodem HTML):',
    Paragraphs: 'Paragraphs:',
    pasteWarning: 'Content can not be pasted because it is above the allowed limit',
    Selected: 'Selected: ',
    title: 'Statystyka'
});
